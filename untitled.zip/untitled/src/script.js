let players = JSON.parse(localStorage.getItem("players")) || [];

function addPlayer() {

  const name = document.getElementById("name").value;

  const team = document.getElementById("team").value;

  const age = document.getElementById("age").value;

  const position = document.getElementById("position").value;

  const goals = document.getElementById("goals").value;

  const matches = document.getElementById("matches").value;

  const discord = document.getElementById("discord").value;

  if (!name || !team || !age || !position || !goals || !matches || !discord) {

    alert("Please fill all fields");

    return;

  }

  players.push({ name, team, age, position, goals, matches, discord });

  localStorage.setItem("players", JSON.stringify(players));

  clearInputs();

  showPlayers();

}

function clearInputs() {

  document.querySelectorAll("input").forEach(i => i.value = "");

}

function deletePlayer(index) {

  players.splice(index, 1);

  localStorage.setItem("players", JSON.stringify(players));

  showPlayers();

}

function editPlayer(index) {

  const player = players[index];

  const newName = prompt("Name:", player.name) || player.name;

  const newTeam = prompt("Team:", player.team) || player.team;

  const newAge = prompt("Age:", player.age) || player.age;

  const newPosition = prompt("Position:", player.position) || player.position;

  const newGoals = prompt("Goals:", player.goals) || player.goals;

  const newMatches = prompt("Matches:", player.matches) || player.matches;

  const newDiscord = prompt("Discord Name:", player.discord) || player.discord;

  players[index] = {

    name: newName,

    team: newTeam,

    age: newAge,

    position: newPosition,

    goals: newGoals,

    matches: newMatches,

    discord: newDiscord

  };

  localStorage.setItem("players", JSON.stringify(players));

  showPlayers();

}

function showPlayers() {

  const box = document.getElementById("players");

  box.innerHTML = "";

  players.forEach((p, index) => {

    const playerDiv = document.createElement("div");

    playerDiv.classList.add("player");

    playerDiv.innerHTML = `

      <strong>${p.name}</strong> (${p.age} y/o)<br>

      🏷 Team: ${p.team}<br>

      📌 Position: ${p.position}<br>

      ⚽ Goals: ${p.goals}<br>

      🏟 Matches: ${p.matches}<br>

      💬 Discord: ${p.discord}<br>

    `;

    const editBtn = document.createElement("button");

    editBtn.textContent = "Edit Player";

    editBtn.classList.add("edit-btn");

    editBtn.onclick = () => editPlayer(index);

    const delBtn = document.createElement("button");

    delBtn.textContent = "Delete Player";

    delBtn.classList.add("delete-btn");

    delBtn.onclick = () => deletePlayer(index);

    playerDiv.appendChild(editBtn);

    playerDiv.appendChild(delBtn);

    box.appendChild(playerDiv);

  });

}

showPlayers();